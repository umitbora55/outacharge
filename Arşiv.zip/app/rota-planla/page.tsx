"use client";

import RotaPlanlaContent from './RotaPlanlaContent';

export default function RotaPlanlaPage() {
    return <RotaPlanlaContent />;
}
